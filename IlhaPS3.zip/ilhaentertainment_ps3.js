var page = require('showtime/page');
var service = require('showtime/service');
var http = require('showtime/http');
var plugin = JSON.parse(Plugin.manifest);

var logo = Plugin.path + plugin.icon;

service.create(
    plugin.title,
    plugin.id + ":start",
    "Ilha Entertainment PS3",
    true,
    logo
);

function setHeader(page, title, imagem){

    page.type = "directory";
    page.contents = "items";
    page.loading = false;

    page.metadata.title = title;

    if(imagem){

        page.metadata.logo = imagem;

    }else{

        page.metadata.logo = logo;

    }

}

var BASE="https://raw.githubusercontent.com/Ilha-Entertainment/PS3-Gratis/main/";

var UPDATE_API =
"https://script.google.com/macros/s/AKfycbwA4h4vN0xqGBw5ZSae47Ekmf83S5wH_8ASq281o1hWQYO8sB3fMcnTO8PKJD4AbbHb/exec?plugin=Ilha%20PS3";

var CATEGORIAS=
"https://script.google.com/macros/s/AKfycbw0prKaneeUMjbJpa6E_OmZ-o0EYSZZmYVmjQgD6MZVb52MFijmFv51P4Xnsct0rhO5SA/exec?acao=ps3";

new page.Route(plugin.id+":start",function(page){

    setHeader(page,"Ilha Entertainment PS3");

    page.options.createAction(
        "updatePlugin",
        "Verificar atualização",
        function () {
            page.redirect(plugin.id + ":update");
        }
    );

    var categorias=carregarCategorias();


    if(categorias.length==0){

        page.appendPassiveItem("label","",{
            title:"Nenhuma categoria encontrada."
        });

        return;

    }

    for(var i=0;i<categorias.length;i++){

        var cat=categorias[i];


        page.appendItem(

            plugin.id+
            ":categoria:"+
            escape(cat.arquivo),

            "directory",

            {
                title:cat.nome,
                icon:cat.imagem
            }

        );

    }

});

function lerLista(url){

    try{

        var txt=http.request(url).toString();

        txt=txt.replace(/\r/g,"");

        return txt.split("\n");

    }catch(e){

        return [];

    }

}

function carregarCategorias(){

    var linhas=lerLista(CATEGORIAS);

    var lista=[];


    for(var i=0;i<linhas.length;i++){

        if(!linhas[i])
            continue;


        var c=linhas[i].split("\t");


        if(c.length<2)
            continue;


        lista.push({

    nome:c[0].trim(),

    imagem:c[1].trim(),

    arquivo:
    BASE+c[0].trim()+".txt"

});


    }


    return lista;

}

new page.Route(plugin.id+":categoria:(.*)",function(page,arquivo){

    arquivo=unescape(arquivo);

    var categorias=carregarCategorias();

    var titulo="Lista";
    var imagemCategoria="";


    for(var i=0;i<categorias.length;i++){

        if(categorias[i].arquivo==arquivo){

            titulo=categorias[i].nome;
            imagemCategoria=categorias[i].imagem;
            break;

        }

    }


    setHeader(page,titulo,imagemCategoria);
    
    page.loading = true;

    var linhas=lerLista(arquivo);

page.appendItem(
    plugin.id + ":pesquisar:" + escape(arquivo),
    "directory",
    {
        title:"🔍 Pesquisar por letra"
    }
);

    for(var i=1;i<linhas.length;i++){

        if(!linhas[i])
            continue;


        var c=linhas[i].split("\t");


        if(c.length<4)
            continue;


        page.appendItem(
            

    plugin.id+
    ":item:"+
    escape(linhas[i]),

    "directory",

    {
        title:c[2],
        icon:
        "https://tse4.mm.bing.net/th?q="+
        encodeURIComponent(c[2]+" PS3 game cover")
    }

);

    }
page.loading = false;

});

new page.Route(plugin.id + ":pesquisar:(.*)", function(page, arquivo){

    arquivo = unescape(arquivo);

    setHeader(page, "Pesquisar");

    var letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#";

    for(var i = 0; i < letras.length; i++){

        page.appendItem(
            plugin.id + ":letra:" + escape(arquivo) + ":" + letras.charAt(i),
            "directory",
            {
                title: letras.charAt(i)
            }
        );
    }

});

new page.Route(plugin.id + ":letra:(.*):(.*)", function(page, arquivo, letra){

    arquivo = unescape(arquivo);

    setHeader(page, "Jogos - " + letra);

    var categoria = arquivo
        .replace(BASE, "")
        .replace(".txt","");

    var url =
"https://script.google.com/macros/s/AKfycbw0prKaneeUMjbJpa6E_OmZ-o0EYSZZmYVmjQgD6MZVb52MFijmFv51P4Xnsct0rhO5SA/exec?acao=buscarps3" +
"&categoria=" + encodeURIComponent(categoria) +
"&letra=" + encodeURIComponent(letra);

    var linhas = lerLista(url);

    for(var i = 0; i < linhas.length; i++){

        if(!linhas[i])
            continue;

        var c = linhas[i].split("\t");

        if(c.length < 4)
            continue;

        page.appendItem(
            plugin.id + ":item:" + escape(linhas[i]),
            "directory",
            {
                title: c[2],
                icon: "https://tse4.mm.bing.net/th?q=" +
                      encodeURIComponent(c[2] + " PS3 game cover")
            }
        );
    }

});

new page.Route(plugin.id+":item:(.*)",function(page,dados){

    setHeader(page,"Detalhes");

    var c=unescape(dados).split("\t");

    page.appendPassiveItem("label","",{
        title:"Nome: "+c[2]
    });

    page.appendPassiveItem("label","",{
        title:"Title ID: "+c[0]
    });

    page.appendPassiveItem("label","",{
        title:"Região: "+c[1]
    });

    page.appendPassiveItem("label","",{
        title:"Tamanho: "+c[8]
    });

    page.appendItem(
    plugin.id + ":download:" + escape(c[3]),
    "directory",
    {
        title:"⬇ Baixar PKG"
    }
    );

});

new page.Route(plugin.id + ":download:(.*)", function(page, url){

    url = unescape(url);

    showtime.notify(
        "Abrindo no webMAN...",
        3
    );

    try{

        http.request(
            "http://localhost/browser.ps3?" + url
        );

    }catch(e){

        showtime.notify(
            "Erro: " + e,
            5
        );

    }

});

new page.Route(plugin.id + ":update", function(page){

    setHeader(page, "Atualização");

    page.loading = true;

    try{

        var resposta = http.request(UPDATE_API).toString();
        var dados = JSON.parse(resposta);

        if(dados.status != "ok"){

            page.loading = false;

            page.appendPassiveItem("label","",{
                title:"Erro ao consultar atualização."
            });

            return;
        }

        var p = dados.plugin;

        page.metadata.logo = p.logo;

        page.appendPassiveItem("label","",{
            title:"App: " + p.nome
        });

        page.appendPassiveItem("label","",{
            title:"Versão instalada: " + plugin.version
        });

        page.appendPassiveItem("label","",{
            title:"Última versão: " + p.versao
        });

        page.appendPassiveItem("label","",{
            title:"Tamanho: " + p.tamanho
        });

        page.appendPassiveItem("label","",{
            title:"Atualizado em: " + p.atualizado
        });

        if(plugin.version == p.versao){

            page.appendPassiveItem("label","",{
                title:"✅ Seu plugin já está atualizado."
            });

        }else{

            page.appendPassiveItem("label","",{
                title:"🆕 Existe uma nova atualização disponível."
            });
            
            page.appendItem(
                plugin.id + ":baixarupdate:" + escape(p.download),
                "directory",
                {
                    title:"⬇ Baixar atualização"
                }
            );

        }

        page.appendPassiveItem("label","",{
            title:""
        });

        page.appendPassiveItem("bodytext","",{
            title:"Changelog",
            text:p.changelog
        });

        page.loading = false;

    }catch(e){

        page.loading = false;

        page.appendPassiveItem("label","",{
            title:"Erro: " + e
        });

    }

});

new page.Route(plugin.id + ":baixarupdate:(.*)", function(page, url){

    url = unescape(url);

    showtime.notify(
        "Abrindo download...",
        5
    );

    try{

        http.request(
            "http://localhost/browser.ps3?" + url
        );

    }catch(e){

        showtime.notify(
            "Erro ao abrir o download.",
            5
        );

    }

});

new page.Route(plugin.id + ":baixarupdate:(.*)", function(page,url){

    url = unescape(url);


    showtime.notify(
        "Abrindo download...",
        5
    );


    http.request(
        "http://localhost/browser.ps3?" + url
    );


});